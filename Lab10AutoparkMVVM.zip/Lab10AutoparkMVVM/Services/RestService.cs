using Lab10AutoparkMVVM.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace Lab10AutoparkMVVM.Services
{
    public class HttpClientHandlerInsecure : HttpClientHandler
    {
        public HttpClientHandlerInsecure()
        {
            ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true;
        }
    }

    public class RestService
    {
        private static readonly HttpClient httpClient = new HttpClient(new HttpClientHandlerInsecure())
        {
            BaseAddress = new Uri("https://localhost:7170/")
        };

        public async Task<List<Car>> GetCarsAsync()
        {
            return await httpClient.GetFromJsonAsync<List<Car>>("cars");
        }

        public async Task<Car> GetCarAsync(int id)
        {
            return await httpClient.GetFromJsonAsync<Car>($"cars/{id}");
        }

        public async Task<Car> CreateCarAsync(Car car)
        {
            var response = await httpClient.PostAsJsonAsync("cars", car);
            return await response.Content.ReadFromJsonAsync<Car>();
        }

        public async Task<Car> UpdateCarAsync(Car car)
        {
            var response = await httpClient.PutAsJsonAsync($"cars/{car.Id}", car);
            return await response.Content.ReadFromJsonAsync<Car>();
        }

        public async Task DeleteCarAsync(int id)
        {
            await httpClient.DeleteAsync($"cars/{id}");
        }
    }
}