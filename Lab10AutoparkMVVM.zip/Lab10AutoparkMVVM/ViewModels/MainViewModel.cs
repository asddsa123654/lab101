using Lab10AutoparkMVVM.Models;
using Lab10AutoparkMVVM.Services;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;

namespace Lab10AutoparkMVVM.ViewModels
{
    public class MainViewModel : BindableBase
    {
        private readonly RestService _restService;

        public MainViewModel()
        {
            _restService = new RestService();
            ReloadCars();
        }

        private async Task ReloadCars()
        {
            var items = await _restService.GetCarsAsync();
            var result = items.OrderBy(x => x.Id).ToList();
            Cars.Clear();
            result.ForEach(x => Cars.Add(x));
        }

        public ObservableCollection<Car> Cars { get; set; } = new ObservableCollection<Car>();

        private string _newBrand;
        public string NewBrand
        {
            get => _newBrand;
            set => SetProperty(ref _newBrand, value);
        }

        private string _newModel;
        public string NewModel
        {
            get => _newModel;
            set => SetProperty(ref _newModel, value);
        }

        private int _newYear;
        public int NewYear
        {
            get => _newYear;
            set => SetProperty(ref _newYear, value);
        }

        private string _newStatus;
        public string NewStatus
        {
            get => _newStatus;
            set => SetProperty(ref _newStatus, value);
        }

        public async Task SaveNewCar()
        {
            await _restService.CreateCarAsync(new Car
            {
                Brand = NewBrand,
                Model = NewModel,
                Year = NewYear,
                Status = NewStatus
            });
            await ReloadCars();
            ClearNewCar();
        }

        public void ClearNewCar()
        {
            NewBrand = "";
            NewModel = "";
            NewYear = 0;
            NewStatus = "";
        }
    }
}